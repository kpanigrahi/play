package requests

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"

	"../../../app/github/core"
	"./artifacts"
)

// Create function creates a new entry
func Create(w http.ResponseWriter, r *http.Request) {
	messageRequest := Request{}
	_ = json.NewDecoder(r.Body).Decode(&messageRequest)

	createFileRequest := core.CreateFileRequest{}
	createFileRequest.Message = "Initial request"
	createFileRequest.Committer = core.Committer{Name: messageRequest.Developer, Email: ORequestContext.Config.Profile.Email}

	content, _ := json.MarshalIndent(messageRequest, "", "  ")
	sEnc := base64.StdEncoding.EncodeToString(content)
	createFileRequest.Content = sEnc
	// create the request directly on github
	createFileResponse := core.CreateFile(setGithubContext(), ORequestContext.Config.Github.Paths.Migrations+"/requests/"+messageRequest.Name+".json", createFileRequest)
	if createFileResponse.Content.SHA == "" {
		// if there is any error then raise error
		messageResponse := CreateResponse{}
		messageResponse.Request = messageRequest
		messageResponse.Message = Message{Type: Error, Message: "Request name already present, please select a different request name."}
		sendResponse(w, messageResponse)
		return
	}
	artifacts.OArtifactsContext.Config = ORequestContext.Config
	// since there is no error, please proceed
	for indx, artifact := range messageRequest.Artifacts {
		switch artifactType := artifact.Type; artifactType {
		case ValueSet:
			valueSetRequest := artifacts.ValueSetCreateRequest{Name: artifact.Name, Module: artifact.Module}
			valueSetResponse := artifacts.UploadValueSet(valueSetRequest)
			messageRequest.Artifacts[indx].SHA = valueSetResponse.SHA
			messageRequest.Artifacts[indx].URL = valueSetResponse.URL
			// case DataModel:
			// 	dataModelRequest := artifacts.DataModelCreateRequest{Name: artifact.Name, Module: artifact.Module}
			// 	dataModelResponse := artifacts.UploadDataModel(dataModelRequest)
			// 	messageRequest.Artifacts[indx].SHA = dataModelResponse.SHA
			// 	messageRequest.Artifacts[indx].URL = dataModelResponse.URL

			// case DataReport:
			// 	dataReportRequest := artifacts.DataReportCreateRequest{Name: artifact.Name, Module: artifact.Module}
			// 	dataReportRespoonse := artifacts.UploadDataReport(dataReportRequest)
			// 	messageRequest.Artifacts[indx].SHA = dataReportRespoonse.SHA
			// 	messageRequest.Artifacts[indx].URL = dataReportRespoonse.URL

			// case HCMExtract:
			// 	hcmExtractRequest := artifacts.HCMExtractCreateRequest{Name: artifact.Name, Module: artifact.Module}
			// 	hcmExtractResponse := artifacts.UploadHCMExtract(hcmExtractRequest)
			// 	messageRequest.Artifacts[indx].SHA = hcmExtractResponse.SHA
			// 	messageRequest.Artifacts[indx].URL = hcmExtractResponse.URL

			// case PayrollFlow:
			// 	payrollFlowRequest := artifacts.PayrollFlowCreateRequest{Name: artifact.Name, Module: artifact.Module}
			// 	payrollFlowResponse := artifacts.UploadPayrollFlow(payrollFlowRequest)
			// 	messageRequest.Artifacts[indx].SHA = payrollFlowResponse.SHA
			// 	messageRequest.Artifacts[indx].URL = payrollFlowResponse.URL

			// case FastFormula:
			// 	fastFormulaRequest := artifacts.FastFormulaCreateRequest{Name: artifact.Name, Module: artifact.Module}
			// 	fastFormulaResponse := artifacts.UploadFastFormula(fastFormulaRequest)
			// 	messageRequest.Artifacts[indx].SHA = fastFormulaResponse.SHA
			// 	messageRequest.Artifacts[indx].URL = fastFormulaResponse.URL
		}
	}

	createResponse := CreateResponse{}
	createResponse.Request = messageRequest
	// now that all the blobs are already created, create the final commits
	githubReferenceResponse := core.Commit(setGithubContext(), "Created new request for "+messageRequest.Name, []string{"migrations/requests/requests.json"}, []string{uploadRequest(messageRequest).SHA})
	if githubReferenceResponse.Obj.URL != "" {
		createResponse.Message = Message{Type: Response, Message: "Successfully created the request for " + messageRequest.Name}
	} else {
		createResponse.Message = Message{Type: Response, Message: "Unable to create the request for " + messageRequest.Name}
	}
	sendResponse(w, createResponse)
}

func uploadRequest(request Request) core.BlobResponse {
	bReq, err := json.MarshalIndent(request, "", "  ")
	if err != nil {
		fmt.Print(err)
	}
	sEnc := base64.StdEncoding.EncodeToString(bReq)
	blobRequest := core.BlobRequest{Content: sEnc, Encoding: "base64"}

	return core.CreateBlob(setGithubContext(), blobRequest)
}


server
	config
	rest
		handlers
		api
			endpoints
				profiles
				migrations
					prjs
					reqs
			msgs
				profiles
				migrations
					prjs
					reqs
			impls
				profiles
				migrations
					prjs
					reqs
			github
				core
					"github core functionalities"